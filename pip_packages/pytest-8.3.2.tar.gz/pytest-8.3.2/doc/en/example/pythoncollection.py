# run this with $ pytest --collect-only test_collectonly.py
#
from __future__ import annotations


def test_function():
    pass


class TestClass:
    def test_method(self):
        pass

    def test_anothermethod(self):
        pass
