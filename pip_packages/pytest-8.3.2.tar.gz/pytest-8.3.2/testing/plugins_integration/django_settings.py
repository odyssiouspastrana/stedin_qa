from __future__ import annotations


SECRET_KEY = "mysecret"
