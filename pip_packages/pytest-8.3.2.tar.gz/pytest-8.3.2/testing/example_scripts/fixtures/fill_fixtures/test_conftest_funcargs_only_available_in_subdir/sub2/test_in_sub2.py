# mypy: allow-untyped-defs
from __future__ import annotations


def test_2(arg2):
    pass
