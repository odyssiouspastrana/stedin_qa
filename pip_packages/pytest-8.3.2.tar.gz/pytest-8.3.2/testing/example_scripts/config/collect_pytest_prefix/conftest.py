from __future__ import annotations


class pytest_something:
    pass
