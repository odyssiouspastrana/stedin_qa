# mypy: allow-untyped-defs
# content of test_first.py
from __future__ import annotations


def test_1():
    pass
